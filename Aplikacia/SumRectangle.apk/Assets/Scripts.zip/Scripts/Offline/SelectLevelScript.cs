﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;// we need this namespace in order to access UI elements within our script

public class SelectLevelScript : MonoBehaviour
{
    public Button uroven1;
    public Button uroven2;
    public Button uroven3;
    public Button uroven4;
    public Button edit;
    public Button exit;
    public Canvas quitMenu;

    public Button show_question;
    public Canvas question;
    Animator anim;

    


    void Start()

    {
        uroven1 = uroven1.GetComponent<Button>();
        uroven2 = uroven2.GetComponent<Button>();
        uroven3 = uroven3.GetComponent<Button>();
        uroven4 = uroven4.GetComponent<Button>();
        edit = edit.GetComponent<Button>();
        exit = exit.GetComponent<Button>();
        quitMenu = quitMenu.GetComponent<Canvas>();
        quitMenu.enabled = false;

        show_question = show_question.GetComponent<Button>();
        question = question.GetComponent<Canvas>();
        question.enabled = false;
        anim = question.GetComponent<Animator>();
        anim.enabled = false;





    }

    public void Show_question()

    {
        anim.enabled = true;       
        question.enabled = true;
    }

    public void Hide_question()

    {
        anim.enabled = false;
        question.enabled = false;
    }

    public void ExitPress() //this function will be used on our Exit button

    {
        quitMenu.enabled = true; //enable the Quit menu when we click the Exit button        
    }

    public void NoPress() //this function will be used for our "NO" button in our Quit Menu

    {
        quitMenu.enabled = false; //we'll disable the quit menu, meaning it won't be visible anymore        
    }
    public void YesPress() //This function will be used on our "Yes" button in our Quit menu
    {
        Application.Quit(); //this will quit our game. Note this will only work after building the game
    }



    public void StartLevel_1() //this function will be used on our Play button

    {
        Application.LoadLevel(Random.RandomRange(1, 3)); //this will load our first level from our build settings. "1" is the second scene in our game

    }
    public void StartLevel_2() //this function will be used on our Play button

    {
        Application.LoadLevel(Random.RandomRange(3, 5)); //this will load our first level from our build settings. "1" is the second scene in our game

    }
    public void StartLevel_3() //this function will be used on our Play button

    {
        Application.LoadLevel(Random.RandomRange(5, 7)); //this will load our first level from our build settings. "1" is the second scene in our game

    }
    public void StartLevel_4() //this function will be used on our Play button

    {
        Application.LoadLevel(Random.RandomRange(7, 9)); //this will load our first level from our build settings. "1" is the second scene in our game

    }

    public void EditLevel() //this function will be used on our Play button

    {
        Application.LoadLevel(9); //this will load our first level from our build settings. "1" is the second scene in our game

    }
}