﻿using UnityEngine;
using System.Collections;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

public class Lock_Edit : MonoBehaviour {

    public Canvas lock2;
    public Canvas lock3;    
    int locks;

    // Use this for initialization
    void Start()
    {
        Load();
        lock2 = lock2.GetComponent<Canvas>();
        lock2.enabled = false;
        lock2.enabled = true;
        lock3 = lock3.GetComponent<Canvas>();
        lock3.enabled = false;
        lock3.enabled = true;        
        locked(locks);


    }



    public void locked(int pokrok)
    {
        if (pokrok >= 2)
        {
            lock2.enabled = false;

        }
        if (pokrok >= 4)
        {
            lock2.enabled = false;
            lock3.enabled = false;
        }        

    }

    public void Load()
    {
        if (File.Exists(Application.persistentDataPath + "/lock.dat"))
        {
            BinaryFormatter bf = new BinaryFormatter();
            FileStream file = File.Open(Application.persistentDataPath + "/lock.dat", FileMode.Open);
            Locks data = (Locks)bf.Deserialize(file);
            file.Close();

            locks = data.locked;
        }
    }
}
